export class Maps {
    key: string;
    lat: number;
    lng: number;
    time: string;
    constructor(key: string, lat: number, lng: number,time: string){}
}